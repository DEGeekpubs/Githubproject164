<?php
class BaseController
{

    public function __construct()
    {

    }
}