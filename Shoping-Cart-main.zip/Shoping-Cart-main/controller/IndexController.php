<?php
class IndexController
{
    public function indexAction(){
        include 'view/indexView.php';
    }

}

